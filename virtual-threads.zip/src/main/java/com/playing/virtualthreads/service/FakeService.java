package com.playing.virtualthreads.service;

import com.playing.virtualthreads.dto.FakeDto;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

@Service
@Slf4j
public class FakeService {

    public Mono<List<FakeDto>> getDtos() {
        try {
            Thread.sleep(100);
            buildData();
            log.info("[CURRENT THREAD NAME] ".concat(Thread.currentThread().getName()));
        } catch (InterruptedException e) {
            log.error("[EXCEPTION] ".concat(e.toString()));
            Thread.currentThread().interrupt();
        }

        return Mono.just(buildData());
    }

    public List<FakeDto> getDtosNoReactive() {
        try {
            Thread.sleep(100);
            buildData();
            log.info("[CURRENT THREAD NAME] ".concat(Thread.currentThread().getName()));
        } catch (InterruptedException e) {
            log.error("[EXCEPTION] ".concat(e.toString()));
            Thread.currentThread().interrupt();
        }
        return buildData();
    }

    private List<FakeDto> buildData() {
        final List<FakeDto> fakeDtoList = new ArrayList<>();
        for (int x = 1; x <= 20000; x++) {
            fakeDtoList.add(FakeDto.builder()
                .random(UUID.randomUUID())
                .build());
        }
        return fakeDtoList;
    }
}
