package com.playing.virtualthreads.controller;

import com.playing.virtualthreads.dto.FakeDto;
import com.playing.virtualthreads.service.FakeService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import reactor.core.publisher.Mono;

import java.util.List;

@RestController
@RequestMapping("/fake")
@RequiredArgsConstructor
public class FakeController {

    private final FakeService fakeService;

    @GetMapping
    public ResponseEntity<Mono<List<FakeDto>>> getListFakeDto() {
        return ResponseEntity.ok(fakeService.getDtos());
    }

    @GetMapping("/no-reactive")
    public ResponseEntity<List<FakeDto>> getListFakeDtoNoReactive() {
        return ResponseEntity.ok(fakeService.getDtosNoReactive());
    }
}
