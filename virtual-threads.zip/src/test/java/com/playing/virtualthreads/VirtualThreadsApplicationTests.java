package com.playing.virtualthreads;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VirtualThreadsApplicationTests {

	@Test
	void contextLoads() {
	}

}
